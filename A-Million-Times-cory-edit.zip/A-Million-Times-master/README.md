# Clock of Clocks
It's a clock made of alot of clocks. Inspired from A Million Times, by Humans since 1982. This works really well with wallpaper engine to create a cool moving wallpaper.

By Humans Since 1982 ~ https://vimeo.com/60491636
Github Version ~ https://ijarriagada.github.io/A-Million-Times/
